
import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import xlsx from 'xlsx';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(bodyParser.json());

let db;
(async () => {
  db = await open({ filename: './visage_results.db', driver: sqlite3.Database });
  await db.exec(`CREATE TABLE IF NOT EXISTS results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    genId TEXT,
    email TEXT,
    score REAL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
})();

// Load Excel and parse questions
const workbook = xlsx.readFile('./MILESTONE ASSESSMENT_MCQ _ITIL.xlsx');
const sheetName = workbook.SheetNames[0];
const data = xlsx.utils.sheet_to_json(workbook.Sheets[sheetName]);
app.get('/api/questions', (req, res) => res.json(data));

// Submit test results
app.post('/api/submit', async (req, res) => {
  const { genId, email, score } = req.body;
  if (!genId || !email || score === undefined) return res.status(400).json({ error: 'Missing fields' });
  await db.run('INSERT INTO results (genId, email, score) VALUES (?, ?, ?)', [genId, email, score]);
  res.json({ success: true });
});

// Get all results (admin only)
app.get('/api/results', async (req, res) => {
  const rows = await db.all('SELECT * FROM results ORDER BY timestamp DESC');
  res.json(rows);
});

// Serve frontend
app.use(express.static(path.join(__dirname, 'frontend_build')));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'frontend_build', 'index.html')));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`✅ Visage ITIL Portal running on port ${PORT}`));
