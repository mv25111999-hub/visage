
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const xlsx = require('xlsx');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Serve static frontend files
app.use(express.static(path.join(__dirname, 'public')));

// ---- SQLite DB ----
const db = new sqlite3.Database('./visage_results.db');
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    genId TEXT,
    email TEXT,
    score REAL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);
});

// ---- Load Questions from Excel ----
let questions = [];
try {
  const workbook = xlsx.readFile(path.join(__dirname, 'MILESTONE ASSESSMENT_MCQ _ITIL.xlsx'));
  const sheetName = workbook.SheetNames[0];
  const sheet = workbook.Sheets[sheetName];
  const raw = xlsx.utils.sheet_to_json(sheet);

  questions = raw.map((row, index) => {
    const options = [];
    for (let i = 1; i <= 6; i++) {
      const key = `Choice${i}`;
      if (row[key] !== undefined && row[key] !== null && String(row[key]).trim() !== '') {
        options.push(String(row[key]));
      }
    }

    let correctIndex = null;
    if (row.RightChoices) {
      const match = String(row.RightChoices).match(/Choice\s*(\d+)/i);
      if (match) {
        const idx = parseInt(match[1], 10) - 1;
        if (!isNaN(idx)) correctIndex = idx;
      }
    }

    return {
      id: row.QuestionSerialNumber || index + 1,
      text: row.QuestionText || '',
      options,
      correctIndex
    };
  }).filter(q => q.text && q.options.length > 0 && q.correctIndex !== null);
} catch (err) {
  console.error('Error loading questions from Excel:', err);
}

// ---- API: Get Questions (without correct answers) ----
app.get('/api/questions', (req, res) => {
  const safeQuestions = questions.map(q => ({
    id: q.id,
    text: q.text,
    options: q.options
  }));
  res.json(safeQuestions);
});

// ---- API: Submit Result ----
app.post('/api/submit', (req, res) => {
  const { genId, email, score } = req.body;
  if (!genId || !email || score === undefined) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  const stmt = db.prepare('INSERT INTO results (genId, email, score) VALUES (?, ?, ?)');
  stmt.run(genId, email, score, function (err) {
    if (err) {
      console.error('Error saving result:', err);
      return res.status(500).json({ error: 'Failed to save result' });
    }
    res.json({ success: true });
  });
  stmt.finalize();
});

// ---- API: Get Results (Admin) ----
app.get('/api/results', (req, res) => {
  db.all('SELECT genId, email, score, timestamp FROM results ORDER BY timestamp DESC', (err, rows) => {
    if (err) {
      console.error('Error fetching results:', err);
      return res.status(500).json({ error: 'Failed to fetch results' });
    }
    res.json(rows);
  });
});

// ---- API: Download Results as CSV ----
app.get('/api/results/export', (req, res) => {
  db.all('SELECT genId, email, score, timestamp FROM results ORDER BY timestamp DESC', (err, rows) => {
    if (err) {
      console.error('Error fetching results for export:', err);
      return res.status(500).send('Failed to export');
    }
    let csv = 'Gen ID,Knox Email ID,Score,Timestamp\n';
    rows.forEach(r => {
      csv += `${r.genId},${r.email},${r.score},${r.timestamp}\n`;
    });
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="visage_itil_results.csv"');
    res.send(csv);
  });
});

// ---- Fallback: serve index.html ----
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`✅ Visage ITIL Portal running on port ${PORT}`);
});
