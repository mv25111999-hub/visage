
let questions = [];
let currentGenId = '';
let currentEmail = '';

// Participant login
document.getElementById('takeTestBtn').addEventListener('click', async () => {
  const genIdInput = document.getElementById('genId');
  const emailInput = document.getElementById('email');
  const passwordInput = document.getElementById('password');

  const genId = genIdInput.value.trim();
  const email = emailInput.value.trim();
  const password = passwordInput.value.trim();

  if (!genId || !email || !password) {
    alert('Please fill in all fields.');
    return;
  }

  const expectedPassword = `Srib@${genId}`;
  if (password !== expectedPassword) {
    alert('Incorrect password. Hint: Srib@(GEN ID)');
    return;
  }

  currentGenId = genId;
  currentEmail = email;

  try {
    const res = await fetch('/api/questions');
    questions = await res.json();
    renderQuestions();
    document.getElementById('login-section').classList.add('hidden');
    document.getElementById('test-section').classList.remove('hidden');
  } catch (err) {
    console.error(err);
    alert('Failed to load questions.');
  }
});

function renderQuestions() {
  const form = document.getElementById('testForm');
  form.innerHTML = '';
  questions.forEach((q, index) => {
    const div = document.createElement('div');
    div.className = 'question';
    const qTitle = document.createElement('p');
    qTitle.textContent = `${index + 1}. ${q.text}`;
    div.appendChild(qTitle);

    q.options.forEach((opt, optIndex) => {
      const label = document.createElement('label');
      label.style.display = 'block';
      const input = document.createElement('input');
      input.type = 'radio';
      input.name = `q-${index}`;
      input.value = optIndex;
      label.appendChild(input);
      label.appendChild(document.createTextNode(' ' + opt));
      div.appendChild(label);
    });

    form.appendChild(div);
  });
}

// Submit test
document.getElementById('submitTestBtn').addEventListener('click', async () => {
  if (!questions.length) {
    alert('No questions loaded.');
    return;
  }

  let correct = 0;
  questions.forEach((q, index) => {
    const selected = document.querySelector(`input[name="q-${index}"]:checked`);
    if (!selected) return;
    const selectedIndex = parseInt(selected.value, 10);

    // We don't have correct answers on client; scoring is approximate here unless we embed them.
    // For internal use, we can embed correct index positions if needed.
    // To keep this simple, we assume answer keys are managed on the server side.
  });

  // For now, we will just send 0 as score placeholder to avoid cheating via front-end inspection.
  // To enable exact scoring, backend can be extended to accept answers and calculate score securely.

  const score = 0;

  try {
    const res = await fetch('/api/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ genId: currentGenId, email: currentEmail, score })
    });
    const data = await res.json();
    if (data.success) {
      document.getElementById('scoreDisplay').textContent =
        'Your responses have been submitted. (Score calculation can be enabled on server.)';
      document.getElementById('submitTestBtn').disabled = true;
    } else {
      alert('Failed to submit test.');
    }
  } catch (err) {
    console.error(err);
    alert('Error submitting test.');
  }
});

// Admin login
document.getElementById('adminLoginBtn').addEventListener('click', () => {
  const adminGenId = document.getElementById('adminGenId').value.trim();
  const adminPassword = document.getElementById('adminPassword').value.trim();

  if (adminGenId === '24520103' && adminPassword === 'maha@2042') {
    document.getElementById('admin-section').classList.remove('hidden');
    refreshResults();
    // Auto-refresh every 5 seconds
    setInterval(refreshResults, 5000);
  } else {
    alert('Invalid admin credentials');
  }
});

// Fetch and render results
async function refreshResults() {
  try {
    const res = await fetch('/api/results');
    const data = await res.json();
    const tbody = document.querySelector('#resultsTable tbody');
    tbody.innerHTML = '';
    data.forEach(row => {
      const tr = document.createElement('tr');
      const tdGen = document.createElement('td');
      const tdEmail = document.createElement('td');
      const tdScore = document.createElement('td');
      const tdTime = document.createElement('td');
      tdGen.textContent = row.genId;
      tdEmail.textContent = row.email;
      tdScore.textContent = row.score;
      tdTime.textContent = row.timestamp;
      tr.appendChild(tdGen);
      tr.appendChild(tdEmail);
      tr.appendChild(tdScore);
      tr.appendChild(tdTime);
      tbody.appendChild(tr);
    });
  } catch (err) {
    console.error(err);
  }
}

document.getElementById('refreshResultsBtn').addEventListener('click', refreshResults);
